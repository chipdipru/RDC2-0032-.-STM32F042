/*
********************************************************************************
* COPYRIGHT(c) ��� ���� � ��ϻ, 2019
* 
* ����������� ����������� ��������������� �� �������� ���� ����� (as is).
* ��� ��������������� �������� ������ �����������.
********************************************************************************
*/


#include "KEYs.h"


static void (*KeyPressed)(uint8_t);

static KeyType Keys[KEYS_COUNT];


void TIM17_IRQHandler(void)
{
  DEBOUNCE_TIMER->SR = 0;
  
  uint8_t ActiveCtrlFlag = 0;
    
  for(uint8_t i = 0; i < KEYS_COUNT; i++)
  {
    if (Keys[i].State == KEY_PRESS_PENDING)     
    {
      ActiveCtrlFlag |= (1 << i);
      
      Keys[i].Counter++;
      
      if (Keys[i].Counter == KEYS_DEBOUNCE_TIME)
      {
        ActiveCtrlFlag &= ~(1 << i);
        
        if (GetKeyLevel(i) == KEY_PRESSED_LEVEL)
          KeyPressed(i);
        
        Keys[i].State = 0;
        Keys[i].Counter = 0;
        EXTI->IMR |= 1 << Keys[i].Pin;
      }      
    }
  }
  
  if (ActiveCtrlFlag == 0)
  {
    DEBOUNCE_TIMER->CR1 &= ~TIM_CR1_CEN;
    DEBOUNCE_TIMER->SR = 0;
    DEBOUNCE_TIMER->CNT = 0;
    RCC->DEBOUNCE_TIMER_ENR &= ~DEBOUNCE_TIMER_CLK_EN;
  }
}
//------------------------------------------------------------------------------
void KEYS_ISR(void)
{ 
  for(uint8_t i = 0; i < KEYS_COUNT; i++)
  {
    if (((EXTI->PR & (1 << Keys[i].Pin)) == (1 << Keys[i].Pin)))
    {
      EXTI->PR |= 1 << Keys[i].Pin;     
      EXTI->IMR &= ~(1 << Keys[i].Pin);
    
      Keys[i].State = KEY_PRESS_PENDING;
   
      if ((RCC->DEBOUNCE_TIMER_ENR & DEBOUNCE_TIMER_CLK_EN) != DEBOUNCE_TIMER_CLK_EN)
      { 
        RCC->DEBOUNCE_TIMER_ENR |= DEBOUNCE_TIMER_CLK_EN;
        DEBOUNCE_TIMER->CR1 |= TIM_CR1_CEN;
      }
      
      break;
    }
  }  
}
//------------------------------------------------------------------------------
void EXTI0_1_IRQHandler(void)
{
  KEYS_ISR();
}
//------------------------------------------------------------------------------
#if defined(ADAU1761_DSP) || defined(ADAU1701_DSP)
void EXTI2_3_IRQHandler(void)
{
  KEYS_ISR();
}
#endif  
//------------------------------------------------------------------------------
void Keys_Init(void (*KeyPressedCallback)(uint8_t))
{ 
  Keys[0].Pin = KEY_0_PIN;
  Keys[0].GPIO = KEYS_0_1_GPIO;

#if defined(ADAU1761_DSP) || defined(ADAU1701_DSP)
  Keys[1].Pin = KEY_1_PIN;
  Keys[1].GPIO = KEYS_0_1_GPIO;
  Keys[2].Pin = KEY_2_PIN;
  Keys[2].GPIO = KEYS_2_4_5_GPIO;
#endif  
      
  for(uint8_t i = 0; i < KEYS_COUNT; i++)
  {
    Keys[i].State = 0;
    Keys[i].Counter = 0;
  }
  
  //������, ������ 1 ��
  RCC->DEBOUNCE_TIMER_ENR |= DEBOUNCE_TIMER_CLK_EN;
  DEBOUNCE_TIMER->PSC = DEBOUNCE_TIMER_PSC;
  DEBOUNCE_TIMER->ARR = DEBOUNCE_TIMER_ARR;
  DEBOUNCE_TIMER->DIER = TIM_DIER_UIE;
  RCC->DEBOUNCE_TIMER_ENR &= ~DEBOUNCE_TIMER_CLK_EN;
  NVIC_EnableIRQ(DEBOUNCE_TIMER_IRQ);
  NVIC_SetPriority(DEBOUNCE_TIMER_IRQ, 2);
  
  KeyPressed = KeyPressedCallback;
  
  RCC->APB2ENR |= RCC_APB2ENR_SYSCFGCOMPEN;
  SYSCFG->EXTICR[0] = (5 << (4 * KEY_0_PIN)) | (5 << (4 * KEY_1_PIN)) | (1 << (4 * KEY_2_PIN));
  
#if defined(TAS3251_DSP)
  EXTI->FTSR |= 1 << KEY_0_PIN;
#elif defined(ADAU1761_DSP) || defined(ADAU1701_DSP)
  EXTI->FTSR |= (1 << KEY_0_PIN) | (1 << KEY_1_PIN) | (1 << KEY_2_PIN);
  NVIC_EnableIRQ(EXTI2_3_IRQn);
  NVIC_SetPriority(EXTI2_3_IRQn, 2);
#endif
  
  NVIC_EnableIRQ(EXTI0_1_IRQn);
  NVIC_SetPriority(EXTI0_1_IRQn, 2);
}
//------------------------------------------------------------------------------
uint8_t GetKeyLevel(uint8_t KeyNum)
{
  return ((Keys[KeyNum].GPIO->IDR & (1 << Keys[KeyNum].Pin)) >> Keys[KeyNum].Pin);
}
//------------------------------------------------------------------------------
void Keys_Enable()
{
#if defined(TAS3251_DSP)
  EXTI->IMR |= 1 << KEY_0_PIN;
#elif defined(ADAU1761_DSP) || defined(ADAU1701_DSP)
  EXTI->IMR |= (1 << KEY_0_PIN) | (1 << KEY_1_PIN) | (1 << KEY_2_PIN);
#endif
}





